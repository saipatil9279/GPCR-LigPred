# gpcr_predict/cli.py

import sys
import argparse
import pandas as pd
from Bio import SeqIO

from .features import predict_kmers, predict_aaindex

def main():
    parser = argparse.ArgumentParser(
        prog="gpcr-predict",
        description="Predict GPCR ligand type (small molecule vs peptide) from a FASTA file."
    )
    parser.add_argument(
        "fasta", 
        help="Path to input FASTA file (may contain one or more sequences)."
    )
    parser.add_argument(
        "-o", "--output", 
        default="predictions.csv",
        help="Path to output CSV file (default: predictions.csv)."
    )
    args = parser.parse_args()

    fasta_path = args.fasta
    out_csv = args.output

    # Check we can open the FASTA
    try:
        records = list(SeqIO.parse(fasta_path, "fasta"))
    except FileNotFoundError:
        print(f"Error: FASTA file not found: {fasta_path}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error reading FASTA file: {e}", file=sys.stderr)
        sys.exit(1)

    if not records:
        print(f"No sequences found in FASTA: {fasta_path}", file=sys.stderr)
        sys.exit(1)

    # For each SeqRecord, run both predictions
    rows = []
    for rec in records:
        seq_id = rec.id
        seq_str = str(rec.seq).upper()
        # Build minimal FASTA text for each record
        fasta_text = f">{seq_id}\n{seq_str}\n"

        # 1) k‐mer/Word2Vec‐based prediction
        try:
            km_label, km_proba = predict_kmers(fasta_text)
        except Exception as e:
            km_label, km_proba = "ERROR", 0.0
            print(f"Warning: predict_kmers failed for {seq_id}: {e}", file=sys.stderr)

        # 2) AAIndex‐based prediction
        try:
            aa_label, aa_proba = predict_aaindex(fasta_text)
        except Exception as e:
            aa_label, aa_proba = "ERROR", 0.0
            print(f"Warning: predict_aaindex failed for {seq_id}: {e}", file=sys.stderr)

        rows.append({
            "Sequence_ID": seq_id,
            "Sequence": seq_str,
            "LightGBM_pred_kmers": km_label,
            "LightGBM_proba_kmers": km_proba,
            "LightGBM_pred_aaindex": aa_label,
            "LightGBM_proba_aaindex": aa_proba
        })

    # Build DataFrame
    df = pd.DataFrame(rows)

    # 1) Print to console
    print("\n===== GPCR Ligand Predictions =====")
    print(df.to_string(index=False))
    print("===================================\n")

    # 2) Save to CSV
    try:
        df.to_csv(out_csv, index=False)
        print(f"Predictions saved to: {out_csv}")
    except Exception as e:
        print(f"Error saving CSV: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
