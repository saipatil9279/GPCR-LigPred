# setup.py

from setuptools import setup, find_packages

setup(
    name="gpcr_predict",
    version="0.1.0",
    description="CLI tool to predict GPCR ligand binding (small molecule vs peptide) from sequence",
    author="Sai Patil",
    author_email="saip9@proton.me",
    license="MIT",           
    packages=find_packages(),  # finds gpcr_predict/ automatically
    include_package_data=True, # include files specified in MANIFEST.in or package_data
    package_data={
        "gpcr_predict": ["models/*"]
    },
    install_requires=[
        "lightgbm>=3.3.0",
        "gensim>=4.0.0",
        "biopython>=1.78",
        "numpy>=1.19.0",
        "pandas>=1.1.0",
    ],
    entry_points={
        "console_scripts": [
            "gpcr-predict = gpcr_predict.cli:main"
        ]
    },
    python_requires=">=3.7",
)
