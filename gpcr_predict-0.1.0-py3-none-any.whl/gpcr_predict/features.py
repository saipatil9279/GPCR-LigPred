# gpcr_predict/features.py

import os
import re
import pkg_resources
import joblib
import numpy as np
from io import StringIO
from Bio import SeqIO
from gensim.models import KeyedVectors
from sklearn.preprocessing import StandardScaler, LabelEncoder

# ──── Paths to packaged models ────────────────────────────────────────────

def _resource_file_path(filename: str) -> str:
    return pkg_resources.resource_filename(__name__, os.path.join("models", filename))

_WORD2VEC_KV       = _resource_file_path("word2vec_kmers.kv")
_LGBM_KMERS_PKL    = _resource_file_path("lightgbm_kmers.pkl")
_SCALER_KMERS_PKL  = _resource_file_path("gpcr_kmers_scaler.pkl")
_LE_KMERS_PKL      = _resource_file_path("gpcr_kmers_label_encoder.pkl")
_LGBM_AAINDEX_PKL  = _resource_file_path("lightgbm_aaindex.pkl")
_LE_AAINDEX_PKL    = _resource_file_path("label_encoder.pkl")
_AAINDEX_TXT       = _resource_file_path("aaindex1.txt")

# ──── Load and cache models/scalers/encoders ─────────────────────────────────

_W2V_MODEL = None
_LGBM_MODEL_KMERS = None
_SCALER_KMERS = None
_LE_KMERS = None
_LGBM_MODEL_AAINDEX = None
_LE_AAINDEX = None
_AAINDEX_DATA = None

def load_word2vec_kmers() -> KeyedVectors:
    global _W2V_MODEL
    if _W2V_MODEL is None:
        _W2V_MODEL = KeyedVectors.load(_WORD2VEC_KV, mmap="r")
    return _W2V_MODEL

def load_kmers_model_and_artifacts():
    global _LGBM_MODEL_KMERS, _SCALER_KMERS, _LE_KMERS
    if _LGBM_MODEL_KMERS is None:
        _LGBM_MODEL_KMERS = joblib.load(_LGBM_KMERS_PKL)
        if os.path.exists(_SCALER_KMERS_PKL):
            _SCALER_KMERS = joblib.load(_SCALER_KMERS_PKL)
        if os.path.exists(_LE_KMERS_PKL):
            _LE_KMERS = joblib.load(_LE_KMERS_PKL)
    return _LGBM_MODEL_KMERS, _SCALER_KMERS, _LE_KMERS

def load_aaindex_model_and_artifacts():
    global _LGBM_MODEL_AAINDEX, _LE_AAINDEX
    if _LGBM_MODEL_AAINDEX is None:
        _LGBM_MODEL_AAINDEX = joblib.load(_LGBM_AAINDEX_PKL)
        if os.path.exists(_LE_AAINDEX_PKL):
            _LE_AAINDEX = joblib.load(_LE_AAINDEX_PKL)
    return _LGBM_MODEL_AAINDEX, _LE_AAINDEX

# ──── AAIndex parser (unchanged) ────────────────────────────────────────────

def parse_aaindex1(path: str) -> dict:
    aa_order = list("ARNDCQEGHILKMFPSTWYV")
    idx_map = {}
    with open(path) as f:
        entries = f.read().split("//")
    for entry in entries:
        lines = [l.strip() for l in entry.split("\n") if l.strip()]
        if not lines:
            continue
        current_id = None
        current_desc = None
        values = []
        for i, line in enumerate(lines):
            if line.startswith("H "):
                current_id = line[2:].strip()
            elif line.startswith("D "):
                current_desc = line[2:].strip()
            elif line.startswith("I "):
                for data_line in lines[i+1:]:
                    if re.match(r"^[-0-9]", data_line):
                        vals = re.findall(r"-?\d+\.?\d*", data_line)
                        values.extend([float(x) for x in vals])
                    else:
                        break
                break
        if current_id and current_desc and len(values) >= 20:
            idx_map[current_id] = {
                "description": current_desc,
                "values": dict(zip(aa_order, values[:20]))
            }
    return idx_map

def load_aaindex_data() -> dict:
    global _AAINDEX_DATA
    if _AAINDEX_DATA is None:
        _AAINDEX_DATA = parse_aaindex1(_AAINDEX_TXT)
    return _AAINDEX_DATA

# ──── Feature‐extraction helpers ────────────────────────────────────────────

def extract_aac(seq: str) -> np.ndarray:
    aa_order = "ACDEFGHIKLMNPQRSTVWY"
    counts = np.array([seq.count(res) for res in aa_order], dtype=float)
    total = counts.sum()
    return counts / total if total > 0 else np.zeros(len(aa_order))

def extract_kmers_w2v(seq: str, w2v_model: KeyedVectors, k: int = 3) -> np.ndarray:
    kmers = [seq[i:i+k] for i in range(len(seq) - k + 1)]
    vecs = [w2v_model[mer] for mer in kmers if mer in w2v_model]
    return np.mean(np.vstack(vecs), axis=0) if vecs else np.zeros(w2v_model.vector_size)

def compute_aaindex_feats(seq: str, aaidx: dict) -> dict:
    L = len(seq)
    feats = {}
    if L == 0:
        for idx_id, data in aaidx.items():
            feats[f"{data['description']} ({idx_id})"] = 0.0
        return feats
    for idx_id, data in aaidx.items():
        total = sum(data["values"].get(aa, 0.0) for aa in seq)
        feats[f"{data['description']} ({idx_id})"] = total / L
    return feats

# ──── “Single‐sequence” wrappers (the part that needed StringIO) ────────────

def extract_kmers_features(fasta_text: str, w2v_model: KeyedVectors) -> np.ndarray:
    """
    Given a single-FASTA string (with header + sequence),
    parse it via StringIO and return a 120‐dim vector:
       [AAC (20‐dim) || W2V (100‐dim)].
    """
    record = next(SeqIO.parse(StringIO(fasta_text), "fasta"))
    seq = str(record.seq).upper()
    aac = extract_aac(seq)
    w2v_vec = extract_kmers_w2v(seq, w2v_model, k=3)
    return np.concatenate([aac, w2v_vec])

def extract_aaindex_features(fasta_text: str, aaidx: dict) -> np.ndarray:
    """
    Given a single-FASTA string, parse it via StringIO and output
    an AAIndex‐based vector (order = sorted keys of aaidx).
    """
    record = next(SeqIO.parse(StringIO(fasta_text), "fasta"))
    seq = str(record.seq).upper()
    feat_dict = compute_aaindex_feats(seq, aaidx)
    keys = sorted(feat_dict.keys())
    return np.array([feat_dict[k] for k in keys])


# ──── Prediction functions (unchanged) ─────────────────────────────────────

def predict_kmers(fasta_text: str) -> (str, float):
    w2v = load_word2vec_kmers()
    model, scaler, le = load_kmers_model_and_artifacts()
    feat = extract_kmers_features(fasta_text, w2v).reshape(1, -1)
    if scaler is not None:
        feat = scaler.transform(feat)
    idx_pred = model.predict(feat)[0]
    proba_all = model.predict_proba(feat)[0]
    proba = proba_all[idx_pred]
    if le is not None:
        label = le.inverse_transform([idx_pred])[0]
    else:
        label = str(idx_pred)
    return label, float(proba)

def predict_aaindex(fasta_text: str) -> (str, float):
    aaidx = load_aaindex_data()
    model, le = load_aaindex_model_and_artifacts()
    feat = extract_aaindex_features(fasta_text, aaidx).reshape(1, -1)
    idx_pred = model.predict(feat)[0]
    proba_all = model.predict_proba(feat)[0]
    proba = proba_all[idx_pred]
    if le is not None:
        label = le.inverse_transform([idx_pred])[0]
    else:
        label = str(idx_pred)
    return label, float(proba)
